<?php
function products_show_controller(){
	return render('catalog.html.php');
}
function catalog_list_controller(){
	return render('catalog.html.php');
}

