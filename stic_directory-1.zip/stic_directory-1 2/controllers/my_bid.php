<?php
function my_bid_show_controller(){
	return render('my_bid.html.php');
}

function my_bid_action_controller(){
	
}