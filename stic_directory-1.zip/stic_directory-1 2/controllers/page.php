<?php

function home_controller()
{
	
    return render('home.html.php');
}

function about_controller()
{
    return render('about.html.php');
}
